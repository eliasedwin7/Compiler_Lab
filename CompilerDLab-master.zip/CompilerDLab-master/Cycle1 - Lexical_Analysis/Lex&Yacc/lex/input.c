void main()
{
    int a=10;
    float b=20;
    char c='c';
    printf("%d,%f,%c",a,b,c);
    a=a+(int)b+(int)c;
    printf("a = %d\n",a);

}