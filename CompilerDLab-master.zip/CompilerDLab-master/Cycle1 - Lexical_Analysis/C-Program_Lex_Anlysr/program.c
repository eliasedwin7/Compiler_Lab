
void main()
{
	int Integer_Var;
	char Character_Var;
	for(int i = 0 ; i < 10 ; )
	{
		printf("Hello World\n");
		i++;
	}
	printf("Enter a Number: ");
	scanf("%d",&Integer_Var);

	Message(Integer_Var)
	return 0
}