### Make sure the input ends with the '$' symbol
[Original Source](https://programsinengineering.blogspot.com/2016/03/to-generate-first-and-follow-for-given.html#more)