# Please Dont Copy This
> Its not for me but you ..