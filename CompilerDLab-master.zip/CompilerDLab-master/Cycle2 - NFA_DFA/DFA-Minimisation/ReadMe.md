### Source = https://github.com/PhilGabardo/DFA-Minimization

## Compiling
	g++ Minimisation.c
## Inputing
	You need to put input in a file and pass in terminal
	Eg: ./a.out < inputfile
